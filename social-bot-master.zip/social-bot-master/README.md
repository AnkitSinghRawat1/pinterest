# social-bot

Social bot for Pinterest, Medium, Instagram and Twitter