from selenium import webdriver
from selenium.webdriver.common.by import By
import time , random

from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait


driver = webdriver.Chrome("..\drivers\chromedriver.exe")

driver.get("https://in.pinterest.com")

driver.maximize_window()


user_name = driver.find_element_by_name("id")
user_name.send_keys("ankitsr2023@gmail.com")
time.sleep(1)
password = driver.find_element_by_name("password")

password.send_keys("Anki@1212")
time.sleep(1)
driver.find_element_by_xpath("/html/body/div[1]/div/div/div/div/div/div[3]/div/div[1]/div/div/div[1]/div/div/div[1]/div[4]/div/div[1]/form/div[3]/button").click()

time.sleep(4)
# driver.get("https://in.pinterest.com/getdatgadget/_followers/")
driver.get("https://in.pinterest.com/techcrunch/_followers/")


time.sleep(2)
# names = driver.find_elements(By.CSS_SELECTOR , ".tBJ.dyH.iFc.SMy._S5.pBj.DrD.IZT.mWe")
# print(len(names))
# for name in names:
#     print(name.text)






# 1. scroll down page by pixel
# driver.execute_script("window.scrollBy(0,2000)","")

# 2. scroll down page till the page end
# driver.execute_script("window.scrollBy(0,document.body.scrollHeight)")

# driver.get("https://in.pinterest.com/getdatgadget/_followers/")

# time.sleep(5)
# a = driver.find_elements(By.CSS_SELECTOR , ".RCK.Hsu.DZT.I56.GmH.adn.Il7.Jrn.hNT.iyn.BG7.gn8.L4E.kVc._Vw")
# for s in a:
#     s.click()
#
# a = driver.find_elements(By.CSS_SELECTOR , ".rLK.iyn.DI9.BG7.Xs7.gL3.FTD.L4E")
# for s in a:
#     s.click()

# wait = WebDriverWait(driver,10)


# a =wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR , ".RCK.Hsu.DZT.I56.GmH.adn.Il7.Jrn.hNT.iyn.BG7.gn8.L4E.kVc._Vw")))


# driver.execute_script("window.scrollBy(0,2000)", "")
for i in range(0,50):
    print(i)
    a = driver.find_element(By.CSS_SELECTOR , ".RCK.Hsu.DZT.I56.GmH.adn.Il7.Jrn.hNT.iyn.BG7.gn8.L4E.kVc._Vw")
    a.click()
    time.sleep(1)
    if i%5==0:
        driver.execute_script("window.scrollBy(0,150)", "")
    else:
        driver.execute_script("window.scrollBy(0,90)", "")
    time.sleep(1)



